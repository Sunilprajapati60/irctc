# IRCTC Autofill Extension (Chrome)
Tatkal Autofill Tool which helps you to book tatkal tickets at fast. It autofills and submits all data during booking time.


***Installation***

1) Clone/Download this repository on your system.
2) Go to chrome://extensions/ via google chrome
3) click Load unpacked on top-left and then select the downloaded repository folder.
4) Finally, Activate this extensions, then you can use it.


***Steps for IRCTC Train Ticket Booking:***

1) Enter all the IRCTC Details and then Click Connect to run the script.


***Steps for Tatkal Ticket Booking,(run before 20 sec @ 10 AM or 11 AM):***

1) Enter all the IRCTC Details and then click Save Data only if you wants to book in future or else you can directly click CONNECT button to book ticket.
2) Click Load Data to load the save data into repective fields.
3) Then Click Connect to run the script.

# Images:


![1](https://user-images.githubusercontent.com/80060364/222964532-f8ed3a9d-955d-4b57-b515-153cd2f68ad8.png)
![2](https://user-images.githubusercontent.com/80060364/222964542-d66aac5b-c1ff-4a56-9d0e-15bd058bdfb4.png)
![3](https://user-images.githubusercontent.com/80060364/222964676-c175c15f-a5e8-4107-9a3b-0be7e4258f66.png)


